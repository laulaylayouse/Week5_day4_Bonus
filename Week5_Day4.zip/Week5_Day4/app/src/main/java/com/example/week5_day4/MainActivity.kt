package com.example.week5_day4

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId)
        {
            R.id.Simple_GET_Request -> {
                val intent = Intent(this@MainActivity,Simple_GET_Request::class.java)
                startActivity(intent)
                Toast.makeText(this,"Simple_GET_Request" , Toast.LENGTH_SHORT)

            }
//            R.id.App_With_Single_Button -> {
//                val intent = Intent(this@MainActivity,AppWithSingleButton::class.java)
//                startActivity(intent)
//                Toast.makeText(this,"AppWithSingleButton" , Toast.LENGTH_SHORT)
//
//            }
//            R.id.three_buttons -> {
//                val intent = Intent(this@MainActivity,three_buttons::class.java)
//                startActivity(intent)
//                Toast.makeText(this,"3 buttons" , Toast.LENGTH_SHORT)
//
//            }
//            R.id.MenuApp -> {
//                val intent = Intent(this@MainActivity,MenuApp::class.java)
//                startActivity(intent)
//                Toast.makeText(this,"Menu App" , Toast.LENGTH_SHORT)

            //}
            else -> return super.onOptionsItemSelected(item)
        }
        return super.onOptionsItemSelected(item)
    }
}