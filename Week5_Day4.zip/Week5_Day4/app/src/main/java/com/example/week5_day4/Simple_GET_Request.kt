package com.example.week5_day4

import android.app.ProgressDialog
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Simple_GET_Request : AppCompatActivity() {

    var name=""
    lateinit var TextView_Name: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simple_get_request)

        TextView_Name = findViewById<TextView>(R.id.TextView_Name)

        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)
        val progressDialog = ProgressDialog(this@Simple_GET_Request)
        progressDialog.setMessage("Please wait".uppercase())
        progressDialog.show()

        if (apiInterface != null) {

            apiInterface.getDetails().enqueue(object : Callback<ArrayList<Names.User_Name>> {
                override fun onResponse(
                    call: Call<ArrayList<Names.User_Name>>,
                    response: Response<ArrayList<Names.User_Name>>
                ) {
                    progressDialog.dismiss()
                    for(data in response.body()!!) {
                        name= name + "# "+data.name+"\n"
                    }
                    TextView_Name.text= name


                }

                override fun onFailure(call: Call<ArrayList<Names.User_Name>>, t: Throwable) {
                    progressDialog.dismiss()
                    call.cancel()
                }
            })
        }
    }
}