package com.example.week5_day4

import com.google.gson.annotations.SerializedName

class Names {
    var name: ArrayList<User_Name>? = null

    class User_Name {

        @SerializedName("name")
        var name: String? = null

        constructor( name: String?) {
            this.name = name
        }
    }
}