package com.example.jsonpracticebonus_laila

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.example.jsonpracticebonus_laila.R
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.lang.Exception
import java.net.URL

class MainActivity : AppCompatActivity() {
    lateinit var EditText_Number: EditText
    lateinit var Button_Get: Button
    lateinit var TextView_Name: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        EditText_Number = findViewById(R.id.EditText_Number)
        Button_Get = findViewById(R.id.Button_Get)
        TextView_Name = findViewById(R.id.TextView_Name)
        Button_Get.setOnClickListener {
            val number = EditText_Number.text.toString()
            if (number.isEmpty() || number.toInt() < 1 || number.toInt() > 14) {
                Toast.makeText(this@MainActivity, "Enter a number from 1 to 13", Toast.LENGTH_SHORT)
                    .show()

            } else {

                requestApi(number.toInt()-1)
            }
            EditText_Number.text.clear()
        }

    }

    fun requestApi( number:Int) {
        CoroutineScope(Dispatchers.IO).launch {

            val data = async {
                fetchData()
            }.await()

            if (data.isNotEmpty()) {
                val array =JSONArray(data)
                TextView_Name.setText(array.getJSONObject(number).getString("name"))
            } else {
                Toast.makeText(this@MainActivity, "Something Went wrong", Toast.LENGTH_SHORT)
                    .show()

            }

        }

    }

    private fun fetchData(): String {

        var response = ""
        try {

            response = URL("https://dojo-recipes.herokuapp.com/people/").readText(Charsets.UTF_8)

        } catch (e: Exception) {
            println("Error $e")

        }
        return response

    }


}